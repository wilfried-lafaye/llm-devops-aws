"""
Air Quality Dashboard Backend Application
"""
